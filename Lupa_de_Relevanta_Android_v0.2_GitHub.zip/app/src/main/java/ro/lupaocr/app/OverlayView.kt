package ro.lupaocr.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin


data class MatchTag(
    val termId: String,
    val searchTerm: String,
    val nodePath: String,
    val nodeTitle: String,
    val level: Int,
    val colorHex: String,
    val symbol: String
)

data class VisualMatch(
    val key: String,
    val rect: RectF,
    val ocrText: String,
    val tags: List<MatchTag>
)

private data class TrackedMatch(
    var value: VisualMatch,
    var lastSeenMs: Long
)

class OverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2.4f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = resources.displayMetrics.scaledDensity * 11.5f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
    }
    private val labelBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val tracked = LinkedHashMap<String, TrackedMatch>()
    private var visibleMatches: List<VisualMatch> = emptyList()

    var pulseEnabled: Boolean = true
    var labelsEnabled: Boolean = true
    var onMatchTapped: ((VisualMatch) -> Unit)? = null

    /**
     * Small temporal stabilization: positions are smoothed and a match survives briefly
     * if OCR misses it for one frame. This reduces visual jitter without changing OCR meaning.
     */
    fun setMatches(newMatches: List<VisualMatch>) {
        val now = SystemClock.uptimeMillis()
        val consumed = mutableSetOf<String>()

        for (incoming in newMatches) {
            val existing = findTrackFor(incoming)
            if (existing != null) {
                existing.value = incoming.copy(rect = smooth(existing.value.rect, incoming.rect))
                existing.lastSeenMs = now
                consumed += existing.value.key
            } else {
                tracked[incoming.key] = TrackedMatch(
                    value = incoming.copy(rect = RectF(incoming.rect)),
                    lastSeenMs = now
                )
                consumed += incoming.key
            }
        }

        val iterator = tracked.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.lastSeenMs > 360L) iterator.remove()
        }

        visibleMatches = tracked.values.map { it.value }
        invalidate()
    }

    fun clearMatches() {
        tracked.clear()
        visibleMatches = emptyList()
        invalidate()
    }

    fun currentMatches(): List<VisualMatch> = visibleMatches.map { it.copy(rect = RectF(it.rect)) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (visibleMatches.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val wave = if (pulseEnabled) {
            ((sin((now % 1100L) / 1100.0 * 2.0 * PI) + 1.0) / 2.0).toFloat()
        } else 0.65f

        val radius = resources.displayMetrics.density * 5f

        for (match in visibleMatches) {
            val primary = match.tags.minByOrNull { it.level } ?: continue
            val color = parseColor(primary.colorHex)
            val fillAlpha = (48 + 48 * wave).toInt().coerceIn(0, 150)
            val strokeAlpha = (205 + 45 * wave).toInt().coerceIn(0, 255)

            fillPaint.style = Paint.Style.FILL
            fillPaint.color = withAlpha(color, fillAlpha)
            strokePaint.color = withAlpha(color, strokeAlpha)

            canvas.drawRoundRect(match.rect, radius, radius, fillPaint)
            canvas.drawRoundRect(match.rect, radius, radius, strokePaint)

            if (match.tags.size > 1) drawMultiTagStripe(canvas, match)
            if (labelsEnabled) drawLabel(canvas, match, primary, color)
        }

        if (pulseEnabled) postInvalidateOnAnimation()
    }

    private fun drawMultiTagStripe(canvas: Canvas, match: VisualMatch) {
        val unique = match.tags.distinctBy { it.nodePath }.take(5)
        if (unique.size <= 1) return
        val stripeWidth = (match.rect.width() / unique.size).coerceAtLeast(resources.displayMetrics.density * 3f)
        val h = resources.displayMetrics.density * 3f
        unique.forEachIndexed { index, tag ->
            fillPaint.color = parseColor(tag.colorHex)
            val left = match.rect.left + index * stripeWidth
            canvas.drawRect(left, match.rect.bottom - h, (left + stripeWidth).coerceAtMost(match.rect.right), match.rect.bottom, fillPaint)
        }
    }

    private fun drawLabel(canvas: Canvas, match: VisualMatch, primary: MatchTag, color: Int) {
        val symbols = match.tags
            .distinctBy { it.nodeIdSafe() }
            .take(3)
            .joinToString("") { it.symbol.ifBlank { "●" } }
        val text = "$symbols ${primary.nodeTitle}"
        val padX = resources.displayMetrics.density * 5f
        val padY = resources.displayMetrics.density * 3f
        val width = labelPaint.measureText(text) + padX * 2
        val height = labelPaint.textSize + padY * 2
        val top = (match.rect.top - height - resources.displayMetrics.density * 2f).coerceAtLeast(0f)
        val left = match.rect.left.coerceIn(0f, (this.width - width).coerceAtLeast(0f))
        val rect = RectF(left, top, left + width, top + height)
        labelBgPaint.color = withAlpha(color, 225)
        canvas.drawRoundRect(rect, padY, padY, labelBgPaint)
        canvas.drawText(text, left + padX, top + height - padY - resources.displayMetrics.density, labelPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val x = event.x
        val y = event.y
        val hit = visibleMatches
            .filter { it.rect.contains(x, y) }
            .minByOrNull { it.rect.width() * it.rect.height() }
        if (hit != null) {
            onMatchTapped?.invoke(hit)
            performClick()
            return true
        }
        return false
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun findTrackFor(incoming: VisualMatch): TrackedMatch? {
        tracked[incoming.key]?.let { return it }
        val sameTerm = tracked.values.filter { old ->
            old.value.tags.any { oldTag -> incoming.tags.any { it.termId == oldTag.termId } }
        }
        return sameTerm.minByOrNull { centerDistance(it.value.rect, incoming.rect) }
            ?.takeIf { centerDistance(it.value.rect, incoming.rect) < resources.displayMetrics.density * 90f }
    }

    private fun smooth(old: RectF, fresh: RectF): RectF {
        val oldWeight = 0.32f
        val newWeight = 1f - oldWeight
        return RectF(
            old.left * oldWeight + fresh.left * newWeight,
            old.top * oldWeight + fresh.top * newWeight,
            old.right * oldWeight + fresh.right * newWeight,
            old.bottom * oldWeight + fresh.bottom * newWeight
        )
    }

    private fun centerDistance(a: RectF, b: RectF): Float =
        abs(a.centerX() - b.centerX()) + abs(a.centerY() - b.centerY())

    private fun parseColor(hex: String): Int = try {
        Color.parseColor(hex)
    } catch (_: Exception) {
        Color.rgb(200, 74, 74)
    }

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(
        alpha.coerceIn(0, 255),
        Color.red(color),
        Color.green(color),
        Color.blue(color)
    )

    private fun MatchTag.nodeIdSafe(): String = "$nodePath|$colorHex|$symbol"
}
