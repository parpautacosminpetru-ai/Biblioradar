package ro.lupaocr.app

data class SearchMap(
    val title: String,
    val nodes: List<SearchNode>
) {
    val terms: List<SearchTerm> = nodes.flatMap { it.terms }
}

data class SearchNode(
    val id: String,
    val title: String,
    val level: Int,
    val path: String,
    val colorHex: String,
    val symbol: String,
    val terms: List<SearchTerm>
)

data class SearchTerm(
    val id: String,
    val text: String,
    val nodeId: String,
    val nodeTitle: String,
    val nodePath: String,
    val level: Int,
    val colorHex: String,
    val symbol: String
)

/**
 * Parses a deliberately simple, human-editable hierarchy.
 *
 * Example:
 * @title: Cauzele bătrânirii
 * # Cauze principale | color=#C84848 | symbol=★
 * senescență | îmbătrânire | aging
 * stres oxidativ
 * ## Mecanisme celulare | color=#D88438 | symbol=◆
 * telomer | telomeri | telomeric
 * mitocondrie | mitocondrial
 *
 * Rules:
 * - Heading level is given by 1..6 leading '#'.
 * - Heading options are optional: color=#RRGGBB and symbol=...
 * - Every non-heading line is a term line.
 * - Multiple independent terms on one line can be separated with '|'.
 * - Spaces inside one item are preserved, so phrases work.
 * - Lines starting with // are comments.
 * - No semantic interpretation is performed.
 */
object SearchMapParser {
    private val palette = listOf(
        "#C84A4A", // brick red
        "#D9893D", // amber
        "#3F7394", // scholarly blue
        "#557A55", // muted green
        "#775B91", // violet
        "#3F7C78", // teal
        "#8A6F50"  // parchment brown
    )

    fun parse(raw: String): SearchMap {
        val source = raw.replace("\r\n", "\n").replace('\r', '\n')
        val lines = source.lines()
        var title = "Hartă fără titlu"

        data class MutableNode(
            val id: String,
            val title: String,
            val level: Int,
            val path: String,
            val colorHex: String,
            val symbol: String,
            val rawTerms: MutableList<String> = mutableListOf()
        )

        val nodes = mutableListOf<MutableNode>()
        val stack = mutableListOf<MutableNode>()
        var current: MutableNode? = null
        var nodeCounter = 0

        fun ensureGeneral(): MutableNode {
            current?.let { return it }
            nodeCounter += 1
            val node = MutableNode(
                id = "node-$nodeCounter",
                title = "General",
                level = 1,
                path = "General",
                colorHex = palette[0],
                symbol = "●"
            )
            nodes += node
            stack.clear()
            stack += node
            current = node
            return node
        }

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isBlank() || line.startsWith("//")) continue

            if (line.startsWith("@title:", ignoreCase = true)) {
                title = line.substringAfter(':').trim().ifBlank { title }
                continue
            }

            val headingMatch = Regex("^(#{1,6})\\s+(.+)$").matchEntire(line)
            if (headingMatch != null) {
                val level = headingMatch.groupValues[1].length
                val pieces = headingMatch.groupValues[2]
                    .split('|')
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }

                val nodeTitle = pieces.firstOrNull()?.ifBlank { "Nivel $level" } ?: "Nivel $level"
                val color = pieces
                    .firstOrNull { it.startsWith("color=", ignoreCase = true) }
                    ?.substringAfter('=')
                    ?.trim()
                    ?.let(::normalizeColor)
                    ?: palette[(level - 1).coerceIn(0, palette.lastIndex)]
                val symbol = pieces
                    .firstOrNull { it.startsWith("symbol=", ignoreCase = true) }
                    ?.substringAfter('=')
                    ?.trim()
                    ?.takeIf { it.isNotEmpty() }
                    ?: defaultSymbol(level)

                while (stack.isNotEmpty() && stack.last().level >= level) stack.removeAt(stack.lastIndex)
                val parentPath = stack.lastOrNull()?.path
                val path = if (parentPath.isNullOrBlank()) nodeTitle else "$parentPath → $nodeTitle"

                nodeCounter += 1
                val node = MutableNode(
                    id = "node-$nodeCounter",
                    title = nodeTitle,
                    level = level,
                    path = path,
                    colorHex = color,
                    symbol = symbol
                )
                nodes += node
                stack += node
                current = node
                continue
            }

            val node = ensureGeneral()
            line.split('|')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .forEach { node.rawTerms += it }
        }

        val immutableNodes = nodes.map { node ->
            val uniqueTerms = node.rawTerms
                .distinctBy { KeywordMatcher.normalize(it, ignoreDiacritics = true) }
                .mapIndexed { index, term ->
                    SearchTerm(
                        id = "${node.id}-term-${index + 1}",
                        text = term,
                        nodeId = node.id,
                        nodeTitle = node.title,
                        nodePath = node.path,
                        level = node.level,
                        colorHex = node.colorHex,
                        symbol = node.symbol
                    )
                }
            SearchNode(
                id = node.id,
                title = node.title,
                level = node.level,
                path = node.path,
                colorHex = node.colorHex,
                symbol = node.symbol,
                terms = uniqueTerms
            )
        }

        return SearchMap(title = title, nodes = immutableNodes)
    }

    fun example(): String = """
        @title: Exemplu — hartă de cercetare
        # Tema centrală | color=#C84A4A | symbol=★
        termen principal | variantă principală | expresie exactă
        ## Cauze | color=#D9893D | symbol=◆
        cauză | cauzal | determinare
        ## Instituții | color=#3F7394 | symbol=■
        instituție | instituțional | universitate
        ### Detalii | color=#557A55 | symbol=●
        regulament | statut | procedură
    """.trimIndent()

    private fun normalizeColor(value: String): String {
        val cleaned = value.trim().uppercase()
        return when {
            Regex("^#[0-9A-F]{6}$").matches(cleaned) -> cleaned
            Regex("^[0-9A-F]{6}$").matches(cleaned) -> "#$cleaned"
            else -> "#C84A4A"
        }
    }

    private fun defaultSymbol(level: Int): String = when (level) {
        1 -> "★"
        2 -> "◆"
        3 -> "●"
        4 -> "■"
        5 -> "▲"
        else -> "•"
    }
}
