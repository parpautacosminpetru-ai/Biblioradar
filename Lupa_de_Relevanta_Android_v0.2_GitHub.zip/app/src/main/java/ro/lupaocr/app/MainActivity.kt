package ro.lupaocr.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.RectF
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.OpenableColumns
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    companion object {
        private const val CAMERA_PERMISSION_REQUEST = 1001
        private const val DICTIONARY_FILE_REQUEST = 1002
        private const val MAP_IMPORT_REQUEST = 1003
        private const val MAP_EXPORT_REQUEST = 1004
    }

    private lateinit var previewView: PreviewView
    private lateinit var frozenImageView: ImageView
    private lateinit var overlayView: OverlayView
    private lateinit var statusText: TextView
    private lateinit var mapTitleText: TextView
    private lateinit var detailsText: TextView
    private lateinit var legendText: TextView
    private lateinit var settingsPanel: ScrollView
    private lateinit var mapEditor: EditText
    private lateinit var modeSpinner: Spinner
    private lateinit var limitCheck: CheckBox
    private lateinit var limitSeek: SeekBar
    private lateinit var limitLabel: TextView
    private lateinit var diacriticsCheck: CheckBox
    private lateinit var pulseCheck: CheckBox
    private lateinit var labelsCheck: CheckBox
    private lateinit var signalCheck: CheckBox
    private lateinit var vibrationCheck: CheckBox
    private lateinit var torchButton: Button
    private lateinit var freezeButton: Button
    private lateinit var dictionaryWord: TextView
    private lateinit var dictionaryBody: TextView
    private lateinit var dictionaryCount: TextView

    private lateinit var cameraController: LifecycleCameraController
    private lateinit var textRecognizer: TextRecognizer
    private lateinit var dictionaryDatabase: DictionaryDatabase

    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val ioExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile private var activeMap: SearchMap = SearchMap("Hartă", emptyList())
    @Volatile private var matchConfig = MatchConfig()
    private var cameraActive = false
    private var torchOn = false
    @Volatile private var frozen = false
    @Volatile private var lastDictionaryLookupNorm = ""
    private var lastSignalLevel = 0
    private var lastSignalMs = 0L
    private var toneGenerator: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dictionaryDatabase = DictionaryDatabase(this)
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        activeMap = SearchMapParser.parse(MapStore.loadActiveMapText(this))
        buildUi()
        setupCameraController()
        updateMapUi()
        updateDictionaryCount()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
        }
    }

    private fun buildUi() {
        val ink = Color.rgb(44, 42, 38)
        val parchment = Color.rgb(242, 235, 220)
        val panelColor = Color.rgb(231, 221, 201)
        val accent = Color.rgb(94, 69, 47)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(parchment)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(ink)
        }
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val appTitle = TextView(this).apply {
            text = "LUPA DE RELEVANȚĂ"
            setTextColor(Color.rgb(247, 238, 216))
            textSize = 18f
            setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        }
        header.addView(appTitle)

        mapTitleText = TextView(this).apply {
            setTextColor(Color.rgb(201, 190, 166))
            textSize = 12f
            text = "Hartă activă"
        }
        header.addView(mapTitleText)

        val cameraFrame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(cameraFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        frozenImageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
        }
        cameraFrame.addView(frozenImageView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        overlayView = OverlayView(this).apply {
            isClickable = true
            onMatchTapped = { match -> showMatchDetails(match) }
        }
        cameraFrame.addView(overlayView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        statusText = TextView(this).apply {
            text = "Pregătire OCR…"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(178, 28, 27, 25))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            textSize = 13f
        }
        cameraFrame.addView(statusText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        detailsText = TextView(this).apply {
            text = "Atinge un highlight pentru traseul lui în hartă."
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(170, 28, 27, 25))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            textSize = 12f
            maxLines = 4
        }
        cameraFrame.addView(detailsText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
            setBackgroundColor(panelColor)
        }
        root.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
            text = label
            textSize = 11.5f
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener { action() }
        }

        val mapButton = actionButton("HARTĂ") { showSettingsAndFocusMap() }
        actions.addView(mapButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(3) })

        freezeButton = actionButton("ÎNGHEAȚĂ") { toggleFreezeFrame() }
        actions.addView(freezeButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(3) })

        torchButton = actionButton("LANTERNĂ") { toggleTorch() }
        actions.addView(torchButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(3) })

        val settingsButton = actionButton("SETĂRI") {
            settingsPanel.visibility = if (settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        actions.addView(settingsButton, LinearLayout.LayoutParams(0, dp(48), 1f))

        settingsPanel = ScrollView(this).apply {
            visibility = View.GONE
            isFillViewport = false
            setBackgroundColor(parchment)
        }
        root.addView(settingsPanel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 0.78f))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(18))
        }
        settingsPanel.addView(panel, ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        panel.addView(sectionTitle("Harta de căutare"))
        panel.addView(TextView(this).apply {
            text = "# = nod mare, ## = subnod. Opțional: color=#RRGGBB și symbol=★. Termenii independenți pot fi separați cu |. Expresiile cu spații rămân expresii."
            textSize = 12f
            setTextColor(Color.DKGRAY)
        })

        mapEditor = EditText(this).apply {
            gravity = Gravity.TOP or Gravity.START
            minLines = 7
            maxLines = 14
            setHorizontallyScrolling(false)
            setText(MapStore.loadActiveMapText(this@MainActivity))
            setPadding(dp(9), dp(8), dp(9), dp(8))
            setBackgroundColor(Color.rgb(253, 250, 241))
            setTextColor(Color.rgb(35, 33, 30))
            textSize = 13f
        }
        panel.addView(mapEditor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)).apply { topMargin = dp(6) })

        val mapActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panel.addView(mapActions)
        mapActions.addView(smallButton("APLICĂ") { applyMapFromEditor() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        mapActions.addView(smallButton("IMPORTĂ") { openMapFile() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        mapActions.addView(smallButton("EXPORTĂ") { createMapFile() }, LinearLayout.LayoutParams(0, dp(46), 1f))

        legendText = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(55, 51, 45))
            setPadding(0, dp(6), 0, dp(6))
        }
        panel.addView(legendText)

        panel.addView(sectionTitle("Potrivire OCR"))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        panel.addView(modeRow)
        modeRow.addView(TextView(this).apply { text = "Mod: "; textSize = 13f })
        modeSpinner = Spinner(this)
        modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Exact", "Începe cu", "Conține"))
        modeSpinner.setSelection(1)
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (::limitCheck.isInitialized) limitCheck.isEnabled = position != 0
                if (::limitSeek.isInitialized && ::limitCheck.isInitialized) limitSeek.isEnabled = position != 0 && limitCheck.isChecked
                rebuildConfig()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        modeRow.addView(modeSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        limitCheck = CheckBox(this).apply {
            text = "Folosește doar primele N caractere"
            isChecked = false
            setOnCheckedChangeListener { _, _ ->
                limitSeek.isEnabled = isChecked && modeSpinner.selectedItemPosition != 0
                rebuildConfig()
            }
        }
        panel.addView(limitCheck)

        val limitRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        panel.addView(limitRow)
        limitSeek = SeekBar(this).apply {
            max = 49
            progress = 5
            isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    limitLabel.text = "N = ${progress + 1}"
                    rebuildConfig()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        limitRow.addView(limitSeek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        limitLabel = TextView(this).apply { text = "N = 6"; setPadding(dp(8), 0, 0, 0) }
        limitRow.addView(limitLabel)

        diacriticsCheck = CheckBox(this).apply {
            text = "Ignoră diferența de diacritice"
            isChecked = true
            setOnCheckedChangeListener { _, _ -> rebuildConfig() }
        }
        panel.addView(diacriticsCheck)

        pulseCheck = CheckBox(this).apply {
            text = "Clipire vizuală discretă"
            isChecked = true
            setOnCheckedChangeListener { _, checked -> overlayView.pulseEnabled = checked }
        }
        panel.addView(pulseCheck)

        labelsCheck = CheckBox(this).apply {
            text = "Arată simbolul și nodul lângă highlight"
            isChecked = true
            setOnCheckedChangeListener { _, checked -> overlayView.labelsEnabled = checked; overlayView.invalidate() }
        }
        panel.addView(labelsCheck)

        signalCheck = CheckBox(this).apply {
            text = "Semnal sonor discret la densitate mare (opțional)"
            isChecked = false
        }
        panel.addView(signalCheck)

        vibrationCheck = CheckBox(this).apply {
            text = "Vibrație discretă (opțional)"
            isChecked = false
        }
        panel.addView(vibrationCheck)

        panel.addView(TextView(this).apply {
            text = "Semnalul măsoară doar câte potriviri/noduri din harta ta apar simultan; nu interpretează sensul textului."
            textSize = 11f
            setTextColor(Color.GRAY)
        })

        panel.addView(sectionTitle("Dicționar local"))
        val dictRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        panel.addView(dictRow)
        dictRow.addView(smallButton("IMPORTĂ CSV") { openDictionaryFile() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        dictionaryCount = TextView(this).apply { text = "0 intrări"; gravity = Gravity.CENTER; textSize = 12f }
        dictRow.addView(dictionaryCount, LinearLayout.LayoutParams(0, dp(46), 1f))

        val dictionaryBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(233, 229, 217))
        }
        panel.addView(dictionaryBox)
        dictionaryWord = TextView(this).apply { text = "Dicționar offline"; textSize = 19f; setTextColor(ink) }
        dictionaryBox.addView(dictionaryWord)
        dictionaryBody = TextView(this).apply {
            text = "Atinge un highlight. Dacă termenul există în dicționarul importat, definiția apare aici."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            maxLines = 9
        }
        dictionaryBox.addView(dictionaryBody)

        setContentView(root)
        rebuildConfig()
    }

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        setTextColor(Color.rgb(70, 51, 37))
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun smallButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 11f
        setOnClickListener { action() }
    }

    private fun setupCameraController() {
        cameraController = LifecycleCameraController(this).apply {
            cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
            setImageAnalysisBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            setImageAnalysisResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(1280, 720),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()
            )
            setImageAnalysisAnalyzer(
                analysisExecutor,
                MlKitAnalyzer(
                    listOf(textRecognizer),
                    ImageAnalysis.COORDINATE_SYSTEM_VIEW_REFERENCED,
                    analysisExecutor
                ) { result ->
                    val text = result.getValue(textRecognizer)
                    if (text != null) processOcrResult(text)
                }
            )
        }
        previewView.controller = cameraController
    }

    private fun startCamera() {
        try {
            cameraController.bindToLifecycle(this)
            cameraActive = true
        } catch (e: Exception) {
            cameraActive = false
            Toast.makeText(this, "Camera nu a putut porni: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleTorch() {
        if (!cameraActive) return
        torchOn = !torchOn
        try {
            cameraController.enableTorch(torchOn)
            torchButton.text = if (torchOn) "LANTERNĂ ON" else "LANTERNĂ"
        } catch (_: Exception) {
            torchOn = false
            torchButton.text = "FĂRĂ FLASH"
        }
    }

    private fun toggleFreezeFrame() {
        if (!frozen) {
            val bitmap = previewView.bitmap
            if (bitmap == null) {
                Toast.makeText(this, "Cadrul nu este încă disponibil. Încearcă din nou imediat.", Toast.LENGTH_SHORT).show()
                return
            }
            frozenImageView.setImageBitmap(bitmap)
            frozenImageView.visibility = View.VISIBLE
            frozen = true
            freezeButton.text = "REIA"
            statusText.text = "Cadru înghețat • nimic nu este salvat automat"
        } else {
            frozen = false
            frozenImageView.visibility = View.GONE
            frozenImageView.setImageDrawable(null)
            freezeButton.text = "ÎNGHEAȚĂ"
            statusText.text = "Scanare live reluată"
        }
    }

    private fun processOcrResult(text: Text) {
        if (frozen) return
        val map = activeMap
        val terms = map.terms
        if (terms.isEmpty()) {
            runOnUiThread {
                overlayView.clearMatches()
                statusText.text = "Harta nu conține termeni."
            }
            return
        }

        val config = matchConfig
        data class AreaBuilder(val rect: RectF, var ocrText: String, val tags: MutableList<MatchTag>)
        val byArea = LinkedHashMap<String, AreaBuilder>()
        val matchedTermIds = LinkedHashSet<String>()
        val matchedNodePaths = LinkedHashSet<String>()

        fun add(rect: RectF, ocrText: String, term: SearchTerm) {
            val key = areaKey(rect)
            val builder = byArea.getOrPut(key) { AreaBuilder(RectF(rect), ocrText, mutableListOf()) }
            if (builder.tags.none { it.termId == term.id }) {
                builder.tags += MatchTag(
                    termId = term.id,
                    searchTerm = term.text,
                    nodePath = term.nodePath,
                    nodeTitle = term.nodeTitle,
                    level = term.level,
                    colorHex = term.colorHex,
                    symbol = term.symbol
                )
            }
            matchedTermIds += term.id
            matchedNodePaths += term.nodePath
        }

        for (block in text.textBlocks) {
            for (line in block.lines) {
                val elements = line.elements
                if (elements.isEmpty()) continue

                for (term in terms) {
                    val phraseParts = term.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                    if (phraseParts.size <= 1) {
                        for (element in elements) {
                            if (!KeywordMatcher.matches(element.text, term.text, config)) continue
                            val box = element.boundingBox ?: continue
                            add(RectF(box), element.text, term)
                        }
                    } else {
                        val ranges = findPhraseRanges(elements, phraseParts, config)
                        for (range in ranges) {
                            var union: RectF? = null
                            val words = ArrayList<String>()
                            for (index in range) {
                                val element = elements[index]
                                words += element.text
                                val box = element.boundingBox ?: continue
                                if (union == null) union = RectF(box) else union.union(RectF(box))
                            }
                            union?.let { add(it, words.joinToString(" "), term) }
                        }
                    }
                }
            }
        }

        val matches = byArea.map { (area, builder) ->
            VisualMatch(
                key = "$area|${KeywordMatcher.normalizeToken(builder.ocrText, true)}",
                rect = builder.rect,
                ocrText = builder.ocrText,
                tags = builder.tags.sortedBy { it.level }
            )
        }

        val nodeCounts = matches.flatMap { it.tags }.groupingBy { it.nodePath }.eachCount()
        val signalLevel = structuralSignalLevel(matches.size, matchedNodePaths.size)
        val lights = (1..5).joinToString("") { if (it <= signalLevel) "●" else "○" }
        val strongest = nodeCounts.entries.sortedByDescending { it.value }.take(3)

        runOnUiThread {
            overlayView.setMatches(matches)
            statusText.text = if (matches.isEmpty()) {
                "Nicio potrivire • ${terms.size} termeni activi"
            } else {
                "${matches.size} zone • ${matchedNodePaths.size} noduri • $lights"
            }
            if (matches.isNotEmpty()) {
                detailsText.text = strongest.joinToString("  •  ") { (path, count) -> "$count× ${path.substringAfterLast("→").trim()}" }
            } else {
                detailsText.text = "Scanare live • harta rămâne activă"
            }
            maybeSignal(signalLevel)
        }
    }

    private fun structuralSignalLevel(matchCount: Int, nodeCount: Int): Int = when {
        matchCount >= 10 || nodeCount >= 5 -> 5
        matchCount >= 7 || nodeCount >= 4 -> 4
        matchCount >= 4 || nodeCount >= 3 -> 3
        matchCount >= 2 || nodeCount >= 2 -> 2
        matchCount >= 1 -> 1
        else -> 0
    }

    private fun maybeSignal(level: Int) {
        val now = SystemClock.uptimeMillis()
        if (level >= 3 && level > lastSignalLevel && now - lastSignalMs > 1100L) {
            if (::signalCheck.isInitialized && signalCheck.isChecked) {
                if (toneGenerator == null) toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 12)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 45 + level * 8)
            }
            if (::vibrationCheck.isInitialized && vibrationCheck.isChecked) vibrateBriefly(level)
            lastSignalMs = now
        }
        lastSignalLevel = level
    }

    private fun vibrateBriefly(level: Int) {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        val duration = (18L + level * 5L).coerceAtMost(45L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(duration, 35))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    }

    private fun showMatchDetails(match: VisualMatch) {
        val pathText = match.tags
            .distinctBy { it.nodePath }
            .joinToString("\n") { "${it.symbol} ${it.nodePath}  ←  ${it.searchTerm}" }
        detailsText.text = "„${match.ocrText}”\n$pathText"
        showDictionaryFor(match.ocrText, force = true)
    }

    private fun findPhraseRanges(elements: List<Text.Element>, phraseParts: List<String>, config: MatchConfig): List<IntRange> {
        if (phraseParts.size > elements.size) return emptyList()
        val ranges = ArrayList<IntRange>()
        for (start in 0..elements.size - phraseParts.size) {
            var all = true
            for (offset in phraseParts.indices) {
                if (!KeywordMatcher.matches(elements[start + offset].text, phraseParts[offset], config)) {
                    all = false
                    break
                }
            }
            if (all) ranges += start..(start + phraseParts.size - 1)
        }
        return ranges
    }

    private fun areaKey(rect: RectF): String {
        val bucket = 3
        fun b(value: Float) = value.toInt() / bucket
        return "${b(rect.left)}:${b(rect.top)}:${b(rect.right)}:${b(rect.bottom)}"
    }

    private fun rebuildConfig() {
        if (!::modeSpinner.isInitialized || !::diacriticsCheck.isInitialized || !::limitCheck.isInitialized) return
        val mode = when (modeSpinner.selectedItemPosition) {
            0 -> MatchMode.EXACT
            2 -> MatchMode.CONTAINS
            else -> MatchMode.STARTS_WITH
        }
        val limit = if (mode != MatchMode.EXACT && limitCheck.isChecked) limitSeek.progress + 1 else null
        matchConfig = MatchConfig(mode = mode, characterLimit = limit, ignoreDiacritics = diacriticsCheck.isChecked)
    }

    private fun applyMapFromEditor() {
        try {
            val raw = mapEditor.text.toString()
            val parsed = SearchMapParser.parse(raw)
            if (parsed.terms.isEmpty()) {
                Toast.makeText(this, "Harta nu conține termeni.", Toast.LENGTH_SHORT).show()
                return
            }
            activeMap = parsed
            MapStore.saveActiveMapText(this, raw)
            overlayView.clearMatches()
            updateMapUi()
            Toast.makeText(this, "Hartă activată: ${parsed.terms.size} termeni", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Harta nu a putut fi citită: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun updateMapUi() {
        mapTitleText.text = "${activeMap.title} • ${activeMap.nodes.size} noduri • ${activeMap.terms.size} termeni"
        legendText.text = if (activeMap.nodes.isEmpty()) {
            "Nicio categorie activă."
        } else {
            activeMap.nodes.joinToString("\n") { node ->
                "${"  ".repeat((node.level - 1).coerceAtLeast(0))}${node.symbol} ${node.title}  ${node.colorHex}  (${node.terms.size})"
            }
        }
        statusText.text = "Hartă activă • ${activeMap.terms.size} termeni • scanare simultană"
    }

    private fun showSettingsAndFocusMap() {
        settingsPanel.visibility = View.VISIBLE
        settingsPanel.post { settingsPanel.smoothScrollTo(0, 0); mapEditor.requestFocus() }
    }

    private fun openMapFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
        }
        startActivityForResult(intent, MAP_IMPORT_REQUEST)
    }

    private fun createMapFile() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "harta-relevanta.txt")
        }
        startActivityForResult(intent, MAP_EXPORT_REQUEST)
    }

    private fun importMap(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Fișierul nu poate fi citit.")
            mapEditor.setText(raw)
            applyMapFromEditor()
        } catch (e: Exception) {
            Toast.makeText(this, "Import hartă nereușit: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportMap(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(mapEditor.text.toString()) }
                ?: error("Fișierul nu poate fi scris.")
            Toast.makeText(this, "Harta a fost exportată.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export nereușit: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDictionaryFor(word: String, force: Boolean) {
        val normalized = KeywordMatcher.normalizeToken(word, ignoreDiacritics = true)
        if (normalized.isBlank()) return
        if (!force && normalized == lastDictionaryLookupNorm) return
        lastDictionaryLookupNorm = normalized

        ioExecutor.execute {
            val entries = dictionaryDatabase.lookup(word)
            runOnUiThread {
                dictionaryWord.text = word
                dictionaryBody.text = if (entries.isEmpty()) {
                    "Nu există o intrare exactă pentru acest termen în dicționarele locale importate."
                } else {
                    entries.joinToString("\n\n") { entry ->
                        buildString {
                            if (entry.source.isNotBlank()) append("[${entry.source}]\n")
                            append(entry.definition)
                            if (entry.synonyms.isNotBlank()) append("\nSinonime: ${entry.synonyms}")
                            if (entry.antonyms.isNotBlank()) append("\nAntonime: ${entry.antonyms}")
                        }
                    }
                }
            }
        }
    }

    private fun openDictionaryFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, DICTIONARY_FILE_REQUEST)
    }

    @Deprecated("Deprecated in Android framework; retained to keep this small app dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            DICTIONARY_FILE_REQUEST -> importDictionary(uri)
            MAP_IMPORT_REQUEST -> importMap(uri)
            MAP_EXPORT_REQUEST -> exportMap(uri)
        }
    }

    private fun importDictionary(uri: Uri) {
        dictionaryWord.text = "Import dicționar…"
        dictionaryBody.text = "Se citește fișierul local."
        val sourceName = queryDisplayName(uri).ifBlank { "Dicționar local" }

        ioExecutor.execute {
            try {
                val result = contentResolver.openInputStream(uri)?.use { input ->
                    CsvDictionaryImporter.import(input, sourceName, dictionaryDatabase)
                } ?: error("Fișierul nu poate fi deschis.")

                runOnUiThread {
                    lastDictionaryLookupNorm = ""
                    dictionaryWord.text = "Dicționar importat"
                    dictionaryBody.text = "${result.imported} intrări importate; ${result.skipped} rânduri ignorate."
                    updateDictionaryCount()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dictionaryWord.text = "Import nereușit"
                    dictionaryBody.text = e.message ?: "Format necunoscut."
                }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        } catch (_: Exception) {
            ""
        } finally {
            cursor?.close()
        }
    }

    private fun updateDictionaryCount() {
        ioExecutor.execute {
            val count = dictionaryDatabase.countEntries()
            runOnUiThread { if (::dictionaryCount.isInitialized) dictionaryCount.text = "$count intrări" }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
            else statusText.text = "Permisiunea camerei este necesară pentru lupa OCR."
        }
    }

    override fun onDestroy() {
        try { cameraController.clearImageAnalysisAnalyzer() } catch (_: Exception) { }
        try { cameraController.enableTorch(false) } catch (_: Exception) { }
        toneGenerator?.release()
        textRecognizer.close()
        dictionaryDatabase.close()
        analysisExecutor.shutdown()
        ioExecutor.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
