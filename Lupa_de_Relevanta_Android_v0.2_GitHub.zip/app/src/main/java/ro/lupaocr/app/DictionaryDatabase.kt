package ro.lupaocr.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class DictionaryEntry(
    val term: String,
    val definition: String,
    val synonyms: String,
    val antonyms: String,
    val source: String
)

class DictionaryDatabase(context: Context) : SQLiteOpenHelper(
    context,
    "lupa_dictionary.db",
    null,
    1
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE dictionary_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                term TEXT NOT NULL,
                term_norm TEXT NOT NULL,
                definition TEXT NOT NULL,
                synonyms TEXT NOT NULL DEFAULT '',
                antonyms TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_dictionary_term_norm ON dictionary_entries(term_norm)")
        db.execSQL("CREATE UNIQUE INDEX idx_dictionary_unique ON dictionary_entries(term_norm, source)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun insertOrReplace(entry: DictionaryEntry, db: SQLiteDatabase = writableDatabase) {
        val values = ContentValues().apply {
            put("term", entry.term.trim())
            put("term_norm", normalizeDictionaryTerm(entry.term))
            put("definition", entry.definition.trim())
            put("synonyms", entry.synonyms.trim())
            put("antonyms", entry.antonyms.trim())
            put("source", entry.source.trim())
        }
        db.insertWithOnConflict(
            "dictionary_entries",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun lookup(term: String): List<DictionaryEntry> {
        val normalized = normalizeDictionaryTerm(term)
        if (normalized.isBlank()) return emptyList()

        readableDatabase.query(
            "dictionary_entries",
            arrayOf("term", "definition", "synonyms", "antonyms", "source"),
            "term_norm = ?",
            arrayOf(normalized),
            null,
            null,
            "source COLLATE NOCASE ASC"
        ).use { cursor ->
            val result = ArrayList<DictionaryEntry>()
            while (cursor.moveToNext()) {
                result += DictionaryEntry(
                    term = cursor.getString(0),
                    definition = cursor.getString(1),
                    synonyms = cursor.getString(2),
                    antonyms = cursor.getString(3),
                    source = cursor.getString(4)
                )
            }
            return result
        }
    }

    fun countEntries(): Long {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM dictionary_entries", null).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
    }

    private fun normalizeDictionaryTerm(term: String): String =
        KeywordMatcher.normalizeToken(term, ignoreDiacritics = true)
}
