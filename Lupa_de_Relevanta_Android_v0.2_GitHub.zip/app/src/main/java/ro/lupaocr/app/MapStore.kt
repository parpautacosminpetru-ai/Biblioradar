package ro.lupaocr.app

import android.content.Context

object MapStore {
    private const val PREFS = "lupa_relevanta_maps"
    private const val KEY_ACTIVE_MAP = "active_map_text"

    fun loadActiveMapText(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACTIVE_MAP, null) ?: SearchMapParser.example()
    }

    fun saveActiveMapText(context: Context, raw: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE_MAP, raw)
            .apply()
    }
}
