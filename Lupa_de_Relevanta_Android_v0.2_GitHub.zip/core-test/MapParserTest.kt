package ro.lupaocr.app

fun main() {
    val raw = """
        @title: Cauzele bătrânirii
        # Tema mare | color=#AA0000 | symbol=★
        univers | universitate publică
        ## Subnod | color=#00AA00 | symbol=◆
        telomer | telomeri | stres oxidativ
    """.trimIndent()

    val map = SearchMapParser.parse(raw)
    check(map.title == "Cauzele bătrânirii")
    check(map.nodes.size == 2)
    check(map.terms.size == 5)
    check(map.nodes[1].path == "Tema mare → Subnod")
    check(map.nodes[1].colorHex == "#00AA00")
    check(map.nodes[1].symbol == "◆")

    val prefix = MatchConfig(MatchMode.STARTS_WITH, null, true)
    check(KeywordMatcher.matches("universității", "univers", prefix))
    check(KeywordMatcher.matches("ȚĂRII", "tari", prefix))
    check(!KeywordMatcher.matches("metodologie", "univers", prefix))

    val contains = MatchConfig(MatchMode.CONTAINS, 5, true)
    check(KeywordMatcher.matches("microtelomeric", "telomeri", contains))

    println("OK: map parser + matcher")
}
